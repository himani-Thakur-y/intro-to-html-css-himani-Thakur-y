from passlib.context import CryptContext

# Use bcrypt for secure password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(raw_password: str) -> str:
    """Hash a plain-text password before storing."""
    return pwd_context.hash(raw_password)


def verify_password(raw_password: str, hashed: str) -> bool:
    """Compare a plain-text password against its stored hash."""
    return pwd_context.verify(raw_password, hashed)
