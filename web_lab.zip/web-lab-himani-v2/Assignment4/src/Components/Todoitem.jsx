import React from "react";

// Renders a single task row with controls
function TodoItem({ todo, onToggle, onDelete, onEdit }) {
  return (
    <div style={{ marginBottom: "8px" }}>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}  // mark as done/undone
      />
      {todo.isEditing ? (
        <input
          type="text"
          value={todo.text}
          onChange={(e) => onEdit(todo.id, e.target.value)}  // live edit
        />
      ) : (
        <span style={{ textDecoration: todo.completed ? "line-through" : "" }}>
          {todo.text}
        </span>
      )}
      <button onClick={() => onDelete(todo.id)}>Remove</button>
      <button onClick={() => onEdit(todo.id, todo.text, true)}>
        {todo.isEditing ? "Save" : "Edit"}
      </button>
    </div>
  );
}

export default TodoItem;
