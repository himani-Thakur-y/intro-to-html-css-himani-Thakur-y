import React from "react";
import TodoItem from "./Todoitem";

// Renders the full list of task entries
function TodoList({ todos, onToggle, onDelete, onEdit }) {
  return (
    <div>
      {todos.length === 0 && <p>No tasks yet — add one above!</p>}
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggle={onToggle}
          onDelete={onDelete}
          onEdit={onEdit}
        />
      ))}
    </div>
  );
}

export default TodoList;
