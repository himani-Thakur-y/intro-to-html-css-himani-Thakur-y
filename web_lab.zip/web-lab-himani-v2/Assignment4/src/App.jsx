import React, { useState } from "react";
import TaskList from "./Components/TodoList";

function App() {
  const [taskItems, setTaskItems] = useState([]);  // holds all tasks
  const [inputText, setInputText] = useState("");   // controlled input value

  // Append a new task entry
  const addTask = () => {
    if (inputText.trim() === "") return;
    setTaskItems([
      ...taskItems,
      { id: Date.now(), text: inputText, completed: false, isEditing: false },
    ]);
    setInputText("");
  };

  // Remove a task by its id
  const removeTask = (id) => {
    setTaskItems(taskItems.filter((item) => item.id !== id));
  };

  // Flip the completed flag for a task
  const toggleTask = (id) => {
    setTaskItems(
      taskItems.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  // Update task text or toggle its edit mode
  const updateTask = (id, text, toggleEditMode = false) => {
    setTaskItems(
      taskItems.map((item) =>
        item.id === id
          ? toggleEditMode
            ? { ...item, isEditing: !item.isEditing }
            : { ...item, text }
          : item
      )
    );
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>LAB4 - Task Manager App</h1>
      <input
        type="text"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        placeholder="Type a new task..."
      />
      <button onClick={addTask}>Add Task</button>

      <TaskList
        todos={taskItems}
        onToggle={toggleTask}
        onDelete={removeTask}
        onEdit={updateTask}
      />
    </div>
  );
}

export default App;
