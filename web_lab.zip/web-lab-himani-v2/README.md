# Web Technology Lab - BCT 5th Year

**Student:** Himani Thakur  
**Program:** BCT (Bachelor of Computer Engineering)  
**Year:** 5th Year

---

## Assignments Overview

| Assignment | Topic | Tech Stack |
|---|---|---|
| Assignment1 | Portfolio & Class Schedule | HTML, CSS |
| Assignment2 | JavaScript Basics | Vanilla JS |
| Assignment3 | Login & Register Forms | React + Vite |
| Assignment4 | Task Manager CRUD App | React + Vite |
| Assignment5 | User Auth REST API | FastAPI + SQLite |
| Assignment6 | User Auth + Todo REST API | FastAPI + SQLite |

---

## How to Run

### Assignment 1 & 2 (Plain HTML)
Just open `index.html` directly in your browser, or use VS Code Live Server.

### Assignment 3 & 4 (React + Vite)
```bash
cd Assignment3   # or Assignment4
npm install
npm run dev
```

### Assignment 5 & 6 (FastAPI)
```bash
cd Assignment5   # or Assignment6
pip install fastapi uvicorn sqlalchemy passlib bcrypt pydantic[email]
uvicorn main:app --reload
```
Then open: http://127.0.0.1:8000/docs
