from fastapi import FastAPI
from controllers import router as user_router

# Initialise the FastAPI application
app = FastAPI(title="LAB5 - FastAPI Auth Example")

app.include_router(user_router)
