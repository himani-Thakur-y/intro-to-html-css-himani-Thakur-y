from pydantic import BaseModel, EmailStr


# Schema used when a new user registers
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str


# Schema used when a user logs in
class UserLogin(BaseModel):
    email: EmailStr
    password: str


# Schema returned in API responses (password excluded)
class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr

    class Config:
        orm_mode = True
