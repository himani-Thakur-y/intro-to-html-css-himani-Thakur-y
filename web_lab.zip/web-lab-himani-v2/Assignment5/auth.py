from passlib.context import CryptContext

# Configure bcrypt as the hashing scheme
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(raw_password: str) -> str:
    """Return a bcrypt hash of the given plain-text password."""
    return pwd_context.hash(raw_password)


def verify_password(raw_password: str, hashed_password: str) -> bool:
    """Check whether a plain-text password matches its stored hash."""
    return pwd_context.verify(raw_password, hashed_password)
