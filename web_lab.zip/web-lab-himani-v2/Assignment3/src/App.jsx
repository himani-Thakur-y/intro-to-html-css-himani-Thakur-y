import React, { useState } from "react";
import FormField from "./components/FormField";

function App() {
  // State for the login form fields
  const [loginFields, setLoginFields] = useState({ email: "", password: "" });

  // State for the registration form fields
  const [registerFields, setRegisterFields] = useState({
    name: "",
    email: "",
    password: "",
  });

  // Update login fields on input change
  const onLoginChange = (e) => {
    setLoginFields({ ...loginFields, [e.target.name]: e.target.value });
  };

  // Update register fields on input change
  const onRegisterChange = (e) => {
    setRegisterFields({ ...registerFields, [e.target.name]: e.target.value });
  };

  // Submit login form
  const submitLogin = (e) => {
    e.preventDefault();
    alert(`Login Submitted: ${JSON.stringify(loginFields)}`);
  };

  // Submit registration form
  const submitRegister = (e) => {
    e.preventDefault();
    alert(`Registration Submitted: ${JSON.stringify(registerFields)}`);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>LAB3 - Authentication Forms</h1>

      {/* ---- LOGIN SECTION ---- */}
      <h2>Sign In</h2>
      <form onSubmit={submitLogin}>
        <FormField label="Email" type="email" value={loginFields.email} onChange={onLoginChange} name="email" />
        <FormField label="Password" type="password" value={loginFields.password} onChange={onLoginChange} name="password" />
        <button type="submit">Sign In</button>
      </form>

      {/* ---- REGISTER SECTION ---- */}
      <h2>Create Account</h2>
      <form onSubmit={submitRegister}>
        <FormField label="Full Name" type="text" value={registerFields.name} onChange={onRegisterChange} name="name" />
        <FormField label="Email" type="email" value={registerFields.email} onChange={onRegisterChange} name="email" />
        <FormField label="Password" type="password" value={registerFields.password} onChange={onRegisterChange} name="password" />
        <button type="submit">Create Account</button>
      </form>
    </div>
  );
}

export default App;
