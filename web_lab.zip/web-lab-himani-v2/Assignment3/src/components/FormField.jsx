import React from "react";

// Reusable form field component; receives all config via props
function FormField({ label, type, value, onChange, name }) {
  return (
    <div style={{ marginBottom: "10px" }}>
      <label>
        {label}:{" "}
        <input
          type={type}
          value={value}
          onChange={onChange}
          name={name}
        />
      </label>
    </div>
  );
}

export default FormField;
