// =============================================
// 1. Variable declarations: var, let, const
// =============================================
var varDeclared = "I am var";         // function-scoped
let letDeclared = "I am let";         // block-scoped
const constDeclared = "I am const";   // immutable binding

document.getElementById('variables').innerHTML =
  `varDeclared: ${varDeclared}<br>letDeclared: ${letDeclared}<br>constDeclared: ${constDeclared}`;


// =============================================
// 2. Regular function vs arrow function
// =============================================
function regularAdd(x, y) {
  return x + y;
}

const arrowAdd = (x, y) => x + y; // concise arrow function syntax

document.getElementById('functions').innerHTML =
  `regularAdd(2, 3) = ${regularAdd(2, 3)}<br>arrowAdd(5, 7) = ${arrowAdd(5, 7)}`;


// =============================================
// 3. Object with a method
// =============================================
const userProfile = {
  name: "Himani",
  age: 20,
  greet: function() {
    return `Hello, my name is ${this.name}`; // method using this
  }
};

document.getElementById('objects').innerHTML =
  `userProfile.name: ${userProfile.name}<br>userProfile.age: ${userProfile.age}<br>userProfile.greet(): ${userProfile.greet()}`;


// =============================================
// 4. Array methods: map, filter, spread
// =============================================
const numList = [1, 2, 3, 4, 5];

const multiplied = numList.map(n => n * 2);          // double every element
const evenOnly   = numList.filter(n => n % 2 === 0); // keep even numbers only
const extraNums  = [6, 7, 8];
const merged     = [...numList, ...extraNums];        // merge arrays with spread

document.getElementById('arrays').innerHTML =
  `Original: [${numList}]<br>Doubled: [${multiplied}]<br>Even only: [${evenOnly}]<br>Merged with spread: [${merged}]`;
